import './style.css'
import './javascript.svg'
import { setupCounter } from './counter'

setupCounter(document.querySelector('#counter'))
